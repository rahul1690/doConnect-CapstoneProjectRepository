import { QuestionService } from './../../services/question.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-userdashboard',
  templateUrl: './userdashboard.component.html',
  styleUrls: ['./userdashboard.component.css']
})
export class UserdashboardComponent implements OnInit {

  constructor(private router:Router,private questionService:QuestionService) { }

  footer_ = true;
  ngOnInit(): void {
  }

  search:any;
  askQuestion=true;

  logout(){
    this.router.navigate([""]);
    localStorage.removeItem("token");
  }

  openProfile(){
    this.askQuestion = false;
    this.router.navigate(['dashboard/profile']);
  }

  home(){this.askQuestion = true;
    this.router.navigate(['dashboard']);
  }

  askQuestionPage(){
    this.askQuestion = false;
    this.router.navigate(['dashboard/askquestion'])
  }

  searchQuestion(){
    this.footer_ = false;
    if(this.search != undefined){
    this.router.navigate(["dashboard/questions/",this.search]);
    this.askQuestion = false;
    }
  }
}
