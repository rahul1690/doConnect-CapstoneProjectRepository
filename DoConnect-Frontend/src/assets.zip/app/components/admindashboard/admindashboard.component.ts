import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { QuestionService } from 'src/app/services/question.service';

@Component({
  selector: 'app-admindashboard',
  templateUrl: './admindashboard.component.html',
  styleUrls: ['./admindashboard.component.css']
})
export class AdmindashboardComponent implements OnInit {

  constructor(private router:Router,private questionService:QuestionService) { }

  footer_ = true;
  ngOnInit(): void {
  }

  search:any;
  askQuestion=true;

  logout(){
    this.router.navigate([""]);
    localStorage.removeItem("token");
  }

  openProfile(){
    this.askQuestion = false;
    this.router.navigate(['dashboard/profile']);
  }

  home(){this.askQuestion = true;
    this.router.navigate(['dashboard']);
  }

  askQuestionPage(){
    this.askQuestion = false;
    this.router.navigate(['dashboard/askquestion'])
  }

  searchQuestion(){
    this.footer_ = false;
    if(this.search != undefined){
    this.router.navigate(["dashboard/questions/",this.search]);
    this.askQuestion = false;
    }
  }

  getUsers()
  {
    
  }

}
